CREATE DATABASE  IF NOT EXISTS `constellation` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `constellation`;
-- MySQL dump 10.13  Distrib 5.6.23, for Win32 (x86)
--
-- Host: constellation.mysql.uhserver.com    Database: constellation
-- ------------------------------------------------------
-- Server version	5.6.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `BasketItems`
--

DROP TABLE IF EXISTS `BasketItems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BasketItems` (
  `BasketItemID` int(11) NOT NULL AUTO_INCREMENT,
  `BasketID` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  PRIMARY KEY (`BasketItemID`),
  UNIQUE KEY `BasketID` (`BasketID`),
  KEY `IX_BasketID` (`BasketID`),
  KEY `IX_ProductID` (`ProductID`),
  CONSTRAINT `FK_dbo.BasketItems_dbo.Basket_BasketID` FOREIGN KEY (`BasketID`) REFERENCES `Baskets` (`BasketID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_dbo.BasketItems_dbo.Products_ProductID` FOREIGN KEY (`ProductID`) REFERENCES `Products` (`ProductId`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BasketItems`
--

LOCK TABLES `BasketItems` WRITE;
/*!40000 ALTER TABLE `BasketItems` DISABLE KEYS */;
INSERT INTO `BasketItems` VALUES (1,3,1,1),(2,9,1,1),(3,16,1,1),(5,48,1,1);
/*!40000 ALTER TABLE `BasketItems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Baskets`
--

DROP TABLE IF EXISTS `Baskets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Baskets` (
  `BasketID` int(11) NOT NULL AUTO_INCREMENT,
  `OrderDate` date NOT NULL,
  `BasketGuid` varchar(36) NOT NULL,
  PRIMARY KEY (`BasketID`),
  UNIQUE KEY `BasketID` (`BasketID`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Baskets`
--

LOCK TABLES `Baskets` WRITE;
/*!40000 ALTER TABLE `Baskets` DISABLE KEYS */;
INSERT INTO `Baskets` VALUES (1,'2016-04-08','f6c23a43-beb8-4c34-bf51-03f46f92f71a'),(2,'2016-04-08','dee9f81b-4e01-4011-a812-5f28119f11e9'),(3,'2016-04-08','adc62e88-f5ec-4307-b083-f7308d395a8f'),(4,'2016-04-08','b89a1678-c98e-4db4-a556-cf6b64e9d5d6'),(5,'2016-04-08','2ae89149-acc1-4962-b309-d8de0c6fccc3'),(6,'2016-04-08','beefbe81-912e-4a24-a75b-b837108f7ddd'),(7,'2016-04-08','2cef84ab-da5e-4ca7-8abe-df975b553ba9'),(8,'2016-04-08','b50477ea-f1b6-436f-950c-7fe3d753f5d4'),(9,'2016-04-08','57386acb-cb6e-4553-a260-fb2430b7c4d9'),(10,'2016-04-08','178b985d-2894-4bcd-9932-fef7f13c26fa'),(11,'2016-04-08','b7b4658a-2d54-4a97-89f3-af14dc22887f'),(12,'2016-04-08','e585703f-fd41-4add-8cf1-05b512493540'),(13,'2016-04-08','bdc61dfb-0c41-43e9-a57b-8cfc0f8359a1'),(14,'2016-04-08','6aa2c9d1-f4bc-4478-8fd6-acc3400e77d1'),(15,'2016-04-08','93821f04-4711-44ef-ae46-2dc2741d16ce'),(16,'2016-04-08','ba92d888-df12-486e-96a3-f17ad5f56824'),(17,'2016-04-08','fde84011-7ce8-4a56-b8f5-80e683483ad9'),(18,'2016-04-08','0a8e9049-dcb8-402b-ac35-5d747a38d11d'),(19,'2016-04-08','f3641870-d466-4caf-9546-0382634cfe51'),(20,'2016-04-08','b4853721-c569-487e-be60-28c19f2319f9'),(21,'2016-04-08','206dfe70-1e0c-46ea-b952-532f8df292a4'),(22,'2016-04-08','7d527bf6-979d-463d-9ff8-a633e6c934c3'),(23,'2016-04-08','036e2b79-a9b5-42d9-b2aa-bb15b8075385'),(24,'2016-04-08','95a06789-9800-4dba-83de-a0c93d886f46'),(25,'2016-04-08','f5dbdb59-561f-47e1-864e-476eba4ddc9e'),(26,'2016-04-08','3fad8fb5-3492-4314-a078-64f17c788182'),(27,'2016-04-08','84f35c40-072c-4f3b-b02a-b70654f97705'),(28,'2016-04-08','47f94be6-c7d7-4ae4-bdc9-694414cb85dd'),(29,'2016-04-08','e7e8420c-9459-439a-b858-653fc0d3b056'),(30,'2016-04-08','c7cd9731-2162-4963-a0a1-c0fcaa71d242'),(31,'2016-04-08','6958e68d-abf9-4d27-8a67-8fd533a3b10c'),(32,'2016-04-08','9b46f400-ba8b-41e1-8bfb-cd07d137dfe6'),(33,'2016-04-08','cea26842-d4b9-4394-8420-e166dce130e5'),(34,'2016-04-08','4c2c17e5-72f6-4e03-853e-e90bc98420d5'),(35,'2016-04-08','262e219c-250a-4770-9dc7-cf91e91e2bb9'),(36,'2016-04-08','a1bd7798-10cd-4beb-b5a6-6d17cb6cbf6c'),(37,'2016-04-08','7ee8cb51-2eb7-4815-a591-7b494f3ce4ef'),(38,'2016-04-08','feff04e7-0de1-482a-acfa-6b6f883339ce'),(39,'2016-04-08','f99bc9bf-494a-4dd3-a96e-7e969a122950'),(40,'2016-04-08','f1af4e74-8e93-4c15-9646-dcd3c05276b3'),(41,'2016-04-08','ac58a53b-3e5f-4991-b84d-98d9d8b8b7fe'),(42,'2016-04-08','a372e2a3-bc91-4cb9-8f01-c180bd2cea66'),(43,'2016-04-08','0985e027-64b0-4bb8-88ef-f85c8475154a'),(44,'2016-04-08','d42ab290-b636-43c3-97dd-5402f87b10e8'),(45,'2016-04-08','f4567f06-4a12-49fb-9921-8c0e8ffd6bdb'),(46,'2016-04-08','ff493561-73e1-4fa2-844c-e96b2ec5419e'),(47,'2016-04-08','9708c5ff-69eb-4b98-811f-a1f102c3f565'),(48,'2016-04-08','9cb8dd00-c6b3-44ed-9904-180999be3c58');
/*!40000 ALTER TABLE `Baskets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Customers`
--

DROP TABLE IF EXISTS `Customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Customers` (
  `CustomerId` int(11) NOT NULL AUTO_INCREMENT,
  `CustomerName` longtext,
  `PictureUrl` longtext,
  `Address1` longtext,
  `Address2` longtext,
  `Town` longtext,
  `PostalCode` longtext,
  `HomePhone` longtext,
  `BusinessPhone` longtext,
  `EmailAddress` longtext,
  PRIMARY KEY (`CustomerId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customers`
--

LOCK TABLES `Customers` WRITE;
/*!40000 ALTER TABLE `Customers` DISABLE KEYS */;
INSERT INTO `Customers` VALUES (1,'Darth Vader','https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQAeekMf4fMdIWcadhMTUPM7xOZR2YFKbZO_Mxx_gUfKvTHNT-s4Q',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'The Emperor','https://upload.wikimedia.org/wikipedia/en/8/8f/Emperor_RotJ.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,'Yoda','https://upload.wikimedia.org/wikipedia/en/9/9b/Yoda_Empire_Strikes_Back.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'Chewbacca','data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxQTEhUUExQWFhQXGRwVGRgYFxkaHBcXGxoaGhceGBwbHCggGBsmHRUYITEhJSksLi4uGB8zODMsNygtLisBCgoKDg0OGxAQGi8kICQsLC8sLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLP/AABEIAMwAzAMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABAUDBgcCAQj/xABAEAABAwIDBAcGBQIEBwEAAAABAAIRAyEEEjEFQVFhBhMicYGRoTJCscHR8AcUI+HxUmJyc5KiJDNDgqOywxX/xAAYAQEAAwEAAAAAAAAAAAAAAAAAAQIDBP/EAB8RAQEAAgIDAQEBAAAAAAAAAAABAhEhMQMSE0FRIv/aAAwDAQACEQMRAD8A7iiIgIiICIiAiIgIiIPjnACSYA3lartjp5h6MhgNVw/ps3/Ufkq78Tdu5GDDs1eMz4/p3DxI9FzFzyd3+77Cyyz1dRrh49zdbRtb8RsS6chFITuHzK1x/STEvdJr1Q7/ADHRPITZQntcLye4qLVp2kae83hzHBU3avqRs2zemGNDgeueS2ey7tA9/EQuh9GunTa8NqsyuJjM09nlbVckwYkOO8Md8PoSpuw6mnO/j9FaWxFkr9AAr6tF6M9IHNc2m6DTJgGTY/Rb0tZdsbNCIilAiIgIiICIiAiIgIiICIiAiIgL4TC+rVfxC20aGHyMP6lXsgb8uh+MKLdTaZN3TQOm+ObiMU9wu2zGwdQN54AmVVMwRMQB5rNQw0Nk3fMzuC9guG+eO7yXJcnXJ+K7EUHN+h0PjuUQMmYEEA2+I5ghbA8AtIPl96Ksbh8tQcIPhY+iiZFjHsxkZwd7S3zkDxhZGuDIA3a7/AL28RMHuXii6DESR6K3srpdbIxLnHfy+9y6p0a2gatKHe2zsu5xofELmuyKQlpdceQW39H6bqeLABlj2n0v3LTDLlXPHhuKIi3c4iIgIiICIiAiIgIiICIiAiIgLlXTGsauNqE6U4Y0dwk+Mk+S6quU9ISDiKp0GYk9w+qy8vTXxdqTGU3EANBga7h4qrxe0Or1I7t3grBuIc55Ekcr/BR9qYcHW54alc246OUFnSLObNmBNhw1UjD4sVgToQNCI8xusqnE4STplnzP0XvDEUAcgu7UnTz3lW1L0p7WdrYQT3b/AL3qTQwzX2abD78SqTHlxwodTMOZUBfvGV3ZBtuzQPEJsbHkvgmCDfh9YTLCwxylbZSa5nsz3Stw6I4vrK4ncwnuNh81q9Kk15BA0iS1w043nzW09EsI5uILiLFhHqIPj8lbDsz6rdURF1OUREQEREBERAREQEREBERAREQfHGBJXH9u1Jc9w0LifAG3mV0npVjOroOA1cMo8dVzLaDgB3BYea/jfwz9a/hMR+oRzud5O9WNaZtb5fUqpwlIB2aLkyOQWxZS5m4eluXNc7eKOrTJu1k8z8hvVc+mb3cOLTdpnSx08FebG2vSLK9R9P8AWbDW033i8CBuaBJJNySF4qYjD1BLXOYbnK8WBAA7JF4Jmx0Wstx6ilw3Hvokajm1MLUZT6l4ccwjPnjsTv3ac1KHRgAZ2g52kBw47h3d/wBVg2PQDKgc10Os7IT7bD7zDvstwx+0XNGY+1GU21A9l3kAozy3yYY64UeEwZcZpEioy5B1+F10jo5lLGOboWB3cSYI9FzrZWIzY0EWkXjjqPVdT2ZheraQNJJA4CSp8U3kjy3UTERF1OUREQEREBERAREQEREBERARFD2lisjbQJ94mw8NSg07pfji+sW+4yw5neVpWPqzIK2DaNRpe7KSW8TqeJWvY0WJ3kE+X7lcfku3ZhNRW4aZJsBOpV/hquZsTaw71XYqk2kxpJidOfhvXnC7QZlkOETzF1mumVGXLiGh+VzWuyzZzS0yOMOseKg4fZVCoINQ03QR2hqYtlIsTPFSn40OaTxBI57lHpAF7d06crpMjmdPmP2LiaeKphpNbC0qTW0q3ZEAD2XaXzZrxwV3jMd1rMscHA+QI7kFSKNRnvdmD3F0+kFQ8JYNi4E/X5eqm5EidsOgBWz8CB5fwusYZ8saeIHwXNjQFN1QH2ZFRp4tc0HxMyPBbB0WxVTMZM0ze+6fZha+LLTLy476bciIupyiIiAiIgIiICIiAiIgIiIC0fpxXL6opMA7DOte4n2R7ojSTdX/AEh6RUsK2XEF50ZNz38AuU7W28+s+o89kVDJjc1th981TO8aaYTnaRRr631+cx8FDxNxbeCPmsFOrvOm7u3LHSqyB3z67/D4rlzdGNedqUzUo0T/AEFzD5yCq2jVyzTItB8+KuqDpbUEWIJ7jIhVeKo6u3A685+wqLrDZjJytP8AClYukKT4cdNO6Jj1+KwbBdmc6T7DZI52UbpljAa8akU6cxuflk+hHko1ybZ3bVkkN37/AL5Kx2JSztc0awXAc4+tvFax0f2a55zukN1v6Lc8E9tCXzAa313DvNlN7TOlTV2855Y2PYaBrvvr3T8Vd7J2wbAmATfS4mVoLKjmk23zvBV3sd4LmmezBtOhHHiNVtJYy3t3TB4xlQAscDZSFoHRPpLSpUw2rYl0ZiQPDlot5wuJbUbmaZC6MctxzZY6rMiIrKiIiAiIgIiICIiAtF6d9NRh5pUHfqe8R7vITaVd9NNvDCYcuEdY7ssHPefBcCx2Jc9xcbuJ9Sq2rSfrJiNrPqVC97nOcbkm9vvcpFStJgeyCZncGxb1JWv4skdgTzKzMx0Fwd7LpvvkiJt4eSplFpVrV2lmcAORPOTAEblcYehDYOsZncpNgtf2MGtquDj2jDm8wGmL95CusI5woOe72i8Dwb+yxzjbCsuMf1bb2GsD001UAOdUiRlYLxxO76qXtat1jmRGUgR3yBHxWLHmXik0xuPl+4Wemm33ZuKaC8NaZtmdNtZj5rzQw/W1AHXLrzzt9Vl/KhjQxug9rmT9VJwVIh4PC/0+ATQnlmWpEZabAXW35RfvKpNsYipVZmbZsz4/NXW0agLZHEtd4iD6hQMERcHTfyOk93HvScUvSHgKNbq2uqU8zHDM02vy4jRVuLHVk5HEhxAjQtIkkHv9YK6dhqTPybpAyspk+DRb1XMdodl9KfeF/Mx/7LpuGnPjnta0n5wGnf2jPE8OSu+j2334OoCCXM0c2bEchuK1yrWgiN0g2C9zeTdpt+yp1WncfoDZ2OZWptqU3ZmuEj6EbjyUlcj6I7cOGqA5i6k+Mw5H3hzG/wAV1pjwQCDINweS3xy258sdV6REVlRERAREQERUXTTaRoYSo5phxGUHeJtbmg5b0+21+axRyn9NnYZwse07xPoFqLhLidwUrE2HM38FDdMFUjRX1N5tew/dQXi198eSscW3cO77+9yi1Rc8pA8ApVrL1phpBhzLeGo8pV5s3E9ZSq0p7X/MYO9twFRUm9md5E+H7wVM2U/K9hGrZOu4g2++KpnNxfG6SMBisrW5txhW9ZkVg/c4ZgfD9lT4ijAI749SPQeitME0voNE9pgMHfE28lhl22x6Sa1TtZZjOSAeBA7P3zU/Zzg4u4kxHACfoqN7i6nmOrDPiNPp3Qs9TGZMTAsHNPg8tJI9ZSTad6e6mN/VNM7ibeG7xXrPDwf6mwe8Oj1CUqoeGuInQ8wVGwwz1nA+6I9Z+am4qzJjZ0qq5alB1R/Vk5cktIieJbmAkTAduWbaFIOcx3uwJ8BHxn0WDFbFpCnUqtLgacOINw4l7WAcZmp6JhHF1NvI71tbrhnJvljqOgund8pUrZtbtGdDaFBxInPwNvMr6w2HhPeNfP5LNpF7guy7qzpuPeuo9Bdpl1PqXm7PZ5t0jwXLKDc4a73hfysfgtu6I4rLXpuGjjlPIm11OF1Vc5uOnoiLoc4iIgIiIC57+K9bs0mTeSY3Rx7z8lv9WoGgk6ASuM9N9oOq1S91s3sDgwSAoqY1Sud55+ijMNnE7lmr2UWkey//ABR6KkrSjmAweX8qsxzI8Qf2Vn7wA3bvJQ9qU9PBWVr7THZH3YN/decEL8/qs+FZ2I329T+yzYah7XeP3SkWJaDTB96SPMW9CsuB7JZzlvzXhpkQNBJXvEDK1pH9TXet/oubLtvj089JD1NBjRrUMk/2jX6KtxZJrl245T5NjzspfSkl7KBB0Jb4nT0WTozgBiMbRYRmZmzPBEjq6bSTm5HLHir4RXOo2EYYLZg6t+Nlno56WIGYwHXM7g4S3wut36S7Hw7Gh7aQZUzCC2WiJ7VpjQHcqbZnQs4mi2s2rkLy7subIjMYuDI8lp87MtM/pPXdUm0MS8udSMCk4hxEa5ZLb8JM94C8YMdggDdP3xWXH0X0K1ShUcx76TspLbjQGASAbBwBneFkwtIZvMHxCzvbWThVCrDyDpmE881j6gFZnNhon+r0j78lFayajuGYyeQNoUuuZy+JPiT9FBFts+qREax6i/qr7CVcpDmi1ndxmVreBN54en2Cr/CXaDwkFEux4StnY1w94A+YWVVHRWpmw1PkI8irddEc17ERFKBERBXbdrNbSOcwzVxH9I189PFcS21jeuquee5o4NHsjwC238RtuZ6nUtPYZrHvHf4BaOLgqlq+MV2Kd5lRWmGf91/JZMY/hqSo7NMvP1hUlaaSMG7f4qPihJbPGfC6yU3bm3nd996k7Zw3VvyTJa2LcYutGaLhhI8f4U2lv+9yg4Z1uZ+QWduIDIJMfxyQTMNUh0HQn5KTqL6QR3QZVW+swgljgbxroTpqpDKzg0h+UHeMwJHDSxWHplbxGvtJGKpVsab7DVp4K7/D7G0sPXe+pJcafVsy5feILjdwmzYte6osXXDiDv0MEdwXmmACAdRIG+eY5QZWmMsu9KZWWabr042yypkax13AgSC2N157yJHFb70cwYZQpCxa1oJIuLCTouH18H1jsvazCAwwYjU69+vJWFGpiqDCGkiWkS3MIGhnq9bcVtMtW1lljLjJKxCsa1arVN+tqPf35iSPSFLpmMp7u/7sq/AE+yxlR5aPZYxziLReBYSs5xrSWUzLKjblj2Oacom+kagWmVzXGuiZRXVHAVKgIjK4g77TYqaynaD3+dx81GxV6mawzgZvOPp5KThyI1uDB7ot6k+ahZKwTrkHeCrnZ1bKBOkX+IK10E24g+h1+SvMI20gXFiO/QoOrdCXfoeK2Fa30DqA4fmHQRwWyLox6c+XYiIpVFX7dx/UUH1JggW7zorBaB+Ju1QA2g3X23cuA+KipjnGNrFzjvJ4qM0nz+Ck9XZRqj40Gtj3Lmyz5dOOHCqqtMz9hRqj8pt9wrLG4WTP35KL/wDnP1I+U/VTLyWcNg6AYWnVGLq1ImjTBYOJcTFvBVO1XFznEi9z3SfoFP2AOqrUnNYDEsfrDmu0J4lpkr3tXAA1HkOGXMY7ufNa28MZOWu4fUeqsdn7QxFMgUa9Slc2abGd5GhMKPjNnNbduJaDrD6bgPBzczfOF6w+yq7bh1J4mTleD87a8E/ODjfK3x+KxUB5xJfUAs59KmYbvbBBF7GYmyht2nive/Lu/wAWEw5/+YWf827So0CwEAz/ACVifVlrnZHAi4zCAPXRZe2W9NPXHW1fiX1asuApU3aTTYKTSGG9mACTJC9YPbBy5fyOHdE9o035rzFw7W/osuH2jQLRTrU30XwQHh8scSdbiyu6eGo9UMlau7ubTqm/DQkX0my6ZLrlhbjvhS4zaGb9MYajTeC2Xsc+dJ3uIgr1td7X0SKeFZQcSG9aKzzzIuTEgG6+bRY2mB1eao6TLalN9NwB9q7iQo9Kg0NB6oganK6Y71Bp4wOzADmbUqsfaXMe4E8VNo4cBwc9zn1Mpbme4kkT8ea+03gaCoOFmn6L443vnB/y/oVSy39Xmp+PmLicu8T/AKZtHiFHzEtt7U+s3+CzVqea9+Ehj7cpiy+UerBcXkGf7ssGeYvZV9F/d7wdR1uA+47lfUqhDHFtnZT93VS9zJBZYHUZmm/IghTKmLDWkZZns3NxNt1ikwy30e812m0dv1mHBgVHUw58P6txaHw9rZeAb2Omi7wvzXtF4LKQkBzC54/ukiw4ezrzW3fiT0wq1arKWFqluHA7T2OjrH72ki8N0jibrZg7Mi4d+H/SZ9F73veTTawlzC835tBsXLt1GoHNDhoQCO43CmxEr050CVzDbexn1Kj6jpJcZ8Nw8l1AhYKuFadyplNr43TjeK2U5oMKvfhImdN/JdjxWxGumypMT0bsbLny8VdGPljm4wnLtDlqOS8fl4dfXmtyxPR5w01Gh+RVbidj5rwQRyWdwsaTKVRmYiQPRYWtjQqyr4Bzb3tu+9FgNExYWVOU8K6tSDjBEO4wsPUmYNjusrR1CbHX3TG/gVjLQZad336FRumoxtoiNSDy+Y+ijY6mGXd2p0GviCVY0mHSNNfl3qPtXEMbTPZ7Ugg8hFo75WvintlqqeT/ADjuNebRY52XO6nJixBAJ4g2HgpjujVTDVqjHEmr6GQCDbUEHUKsrY0OrB7WgQQYjeCrnadOpindbmgkaX03Rew4LtusZ3pyTeVQ8KzF0XSwlzT/ANOpUMCLWh0q0GLDrvbTJ5GpPO5kKrZsKrqHRG/tfJZ37Jrb6v8AufdV98b+p9L/ABOxdanlDmUnwYBIcOy7uibqJU2jRaRlfXpu0PZaZ/8ALKxO2fXBs+TG55uNd6i16Dx7Rk98+qncqNWJuK2oxgH/ABJaDucXtvyIBWbBdI4kh9KoODiHfEhQsU4OyAMaAxoaTlEudq5xtxMDkAvDSRYWVvVHs2ani+sY57sPhsgBcSQwW0Ok+S12riW12TSYGAnsiIggiTbmFFxjYYSmw8O5z4piYYXXmLRJcb5RfVPWTouVq+2b0dpAsqYitmsDlYYdGpBvqrPaXRF2Na8YCmGMpvzlj3dp2eZg6SSC4id4XjZmxKtQiWlreJtbkN67D0c2eyjQa1g1u4nVzt5Kgcg6L/hhjHVB14FKkD2jmBLhvDQN54ldxYwAAAQAIA4BekU7RIIiKEi+EL6iDG6g07lEq7LYVPRRpO1JW2E0qtxHRgHQQttRVuETM60Sr0ZPD0VdjejDjcC/xXSyF5NMcFW+KLTyVy0bAPAghRsZ0eziHNXWHYZp3LG7BM4Kvxk5i3141XFafQZoObtE7gTbxU2p0dc8XGQiwPLuXWPyTOC8uwTOCm+O3uomcnUcwo7DcwWuTyXl+yHO1aW/BdPGDZwQ4Jh3J8k/Ryx2xnbxIWOvsAuGnpddX/IM4L23AM4KPkfVyRnRp0CJlZD0OLgbEE7xb+F1xmBZwWVuGaNytPGr9HLcN+HDX2e9+XQ3+quNldCRSaS1zpduFrAkASLxBW/Bo4L7C0kUtVOH2SB5R4DRWrGwF6RSgREQf//Z',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,'Padmé Amidala','https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcS67_xrpv8qBWX6FNIOTDGMZhENGwZp6mOHHzBJvZRPn3Ebqz1l4w',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `Customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrderItems`
--

DROP TABLE IF EXISTS `OrderItems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrderItems` (
  `OrderItemId` int(11) NOT NULL AUTO_INCREMENT,
  `ProductId` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Price` decimal(18,2) NOT NULL,
  `Order_OrderId` int(11) DEFAULT NULL,
  PRIMARY KEY (`OrderItemId`),
  KEY `IX_Order_OrderId` (`Order_OrderId`),
  CONSTRAINT `FK_dbo.OrderItems_dbo.Orders_Order_OrderId` FOREIGN KEY (`Order_OrderId`) REFERENCES `Orders` (`OrderId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrderItems`
--

LOCK TABLES `OrderItems` WRITE;
/*!40000 ALTER TABLE `OrderItems` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrderItems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Orders`
--

DROP TABLE IF EXISTS `Orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Orders` (
  `OrderId` int(11) NOT NULL AUTO_INCREMENT,
  `OrderDate` date NOT NULL,
  `CustomerId` int(11) NOT NULL,
  PRIMARY KEY (`OrderId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Orders`
--

LOCK TABLES `Orders` WRITE;
/*!40000 ALTER TABLE `Orders` DISABLE KEYS */;
INSERT INTO `Orders` VALUES (1,'0001-01-01',4);
/*!40000 ALTER TABLE `Orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Products`
--

DROP TABLE IF EXISTS `Products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Products` (
  `ProductId` int(11) NOT NULL AUTO_INCREMENT,
  `Description` longtext,
  `ImageUrl` longtext,
  `Price` decimal(18,2) NOT NULL,
  `CostPrice` decimal(18,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`ProductId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Products`
--

LOCK TABLES `Products` WRITE;
/*!40000 ALTER TABLE `Products` DISABLE KEYS */;
INSERT INTO `Products` VALUES (1,'Andromeda','https://i.ytimg.com/vi/0-4XOCGHfLo/maxresdefault.jpg',8.05,21.01),(2,'Sculptor','https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Cartwheel_Galaxy.jpg/1024px-Cartwheel_Galaxy.jpg',7.20,16.50),(3,'Sextans','https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/Eso1524aArtist%E2%80%99s_impression_of_CR7_the_brightest_galaxy_in_the_early_Universe.jpg/1024px-Eso1524aArtist%E2%80%99s_impression_of_CR7_the_brightest_galaxy_in_the_early_Universe.jpg',5.75,12.80),(4,'Ursa Major','https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/M82_HST_ACS_2006-14-a-large_web.jpg/1024px-M82_HST_ACS_2006-14-a-large_web.jpg',12.31,25.43),(5,'Virgo','https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/M104_ngc4594_sombrero_galaxy_hi-res.jpg/1024px-M104_ngc4594_sombrero_galaxy_hi-res.jpg',14.00,28.50);
/*!40000 ALTER TABLE `Products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-08 15:31:17
